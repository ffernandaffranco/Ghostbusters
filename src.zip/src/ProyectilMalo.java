public class ProyectilMalo extends Proyectil {
}
