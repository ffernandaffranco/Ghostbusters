import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {
    // aca iria main, settings, setup, draw, keyPressed
}

//void main() {
//
//    @Override
//    public void keyPressed() {
//        if (keyCode == UP) {
//            jugador.mover(-1); // no es un error, Processing funciona así, el origen de coordenadas esta en la esquina superior izquierda
//        } else if (keyCode == DOWN) {
//            jugador.mover(1);
//        }
//
//        if (key == ' ') {
//            Proyectil p = Leila.disparar();
//            agregarProyectilBueno(p);
//        }
//    }
//}

ProyectilesBuenos<Proyectil> { .................. }