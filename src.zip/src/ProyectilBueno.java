public class ProyectilBueno extends Proyectil {

}
